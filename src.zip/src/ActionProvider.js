// ActionProvider.js
import axios from 'axios';

class ActionProvider {
    constructor(createChatBotMessage, setStateFunc) {
        this.createChatBotMessage = createChatBotMessage;
        this.setState = setStateFunc;
    }

    callAPI(message) {
        axios.get('http://localhost:5000/query?question=' + message)
            // replace with your API endpoint
            .then(response => {
                //console(response.status);
                message = this.createChatBotMessage(response.data.output);
                this.updateChatbotState(message);
            })
            .catch(error => {
                message = this.createChatBotMessage(`Error calling API: ${error}`);
                this.updateChatBotState(message);
            });
    }

    updateChatbotState(message) {

        this.setState(prevState => ({
            ...prevState,
            messages: [...prevState.messages, message]
        }));
    }
}

export default ActionProvider;