import chatbot from './Chatbot';
const BreadcrumbsContainer = ({ sharedBreadcrumbs }) => {
        //const breadcrumbs = ['How many rows are there', 'Who is my top vendor', 'what is the total cost of all invoices', 'what kind of questions i can ask you?'];
        const breadcrumbs = [];
        let sharedData = [];
        //const breadcrumb = "";
        //breadcrumbs.split(',');
        //console.log('inside Breadcrumbs');
        if (typeof sharedBreadcrumbs === undefined) {
            console.log("No bread crumbs");

        } else if (typeof sharedBreadcrumbs === 'object') {
            for (var i = 0; i < sharedBreadcrumbs.length; i++) {
                //console.log(sharedBreadcrumbs.length);
                const val = Object.values(sharedBreadcrumbs)[i];
                //console.log(val);
                breadcrumbs.push(val);
                //console.log(breadcrumbs.length);
            }

        }


        //console.log(breadcrumbs);
        //breadcrumbs.push(sharedBreadcrumbs);

        const handleClick = (breadcrumb) => {
            chatbot.handleSendMessage(breadcrumb);
            //console.log("Trigger api for ${ breadcrumb }");

        };
        //if (breadcrumbs.length === 0 || breadcrumbs.length <= 5) {
        if (breadcrumbs.length === 0) {
            console.log("");
            return ( < div > < /div>);

            }
            const startIndex = 2;
            const endIndex = Math.min(5, breadcrumbs.length);
            console.log(breadcrumbs.length);
            return ( <
                div className = "breadcrumbs" > {
                    breadcrumbs.slice(startIndex, endIndex).map((breadcrumb, index) => ( <
                        div key = { index }
                        className = "breadcrumb"
                        onClick = {
                            () => handleClick(breadcrumb.slice(0, breadcrumb.length - 5))
                        } > { breadcrumb.slice(0, breadcrumb.length - 5) } <
                        /div>
                    ))
                } <
                /div>  
            );
        };
        export default BreadcrumbsContainer;