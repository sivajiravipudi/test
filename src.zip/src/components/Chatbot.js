import React, { useState, useRef, useEffect } from "react";
import { Query, set } from 'mongoose';
import { BeatLoader } from 'react-spinners';
import dataConvertion from './dataConvertion';
import DisplayTable from './DisplayTable';
import chatQuery from "./chatQuery";


let breadcrumbs = [];

const renderTextWithLineBreaks = (text) => {
        console.log(text);
        if (text == undefined)
            return "";
        const lines = text.split('\n');
        return lines.map((line, index) => ( < React.Fragment key = { index } > { line } < br / > < /React.Fragment>));
                };

                const Chatbot = ({ queries }) => {
                        const [messages, setMessages] = useState([]);
                        const [data, setData] = useState([]);
                        const inputRef = useRef(null);

                        const [loading, setLoading] = useState(false);
                        const handleSendMessage = async(question) => {
                            console.log(question);
                            setData([]);
                            let newMessage = inputRef.current.value;
                            if (newMessage === '')
                                newMessage = question;
                            if (newMessage.trim() !== '') {
                                inputRef.current.value = '';
                                setMessages(prevMessages => [...prevMessages, { text: newMessage, sender: 'user', question: '', tableres: '' }]);
                                setLoading(true);
                                try {
                                    const res = await chatQuery(newMessage);
                                    //const testRes = "<Table striped boarded hover><thead><tr><th>Vendor</th><th>Quoted Price</th></tr></thead><tbody><tr><td>CTC Global</td></tr></tbody></table>";
                                    //const dom = new JSDOM('!DOCTYPE html><html><body></body></html>');
                                    //const document = dom.window.document;
                                    //const tableContainer = document.createElement('div');
                                    //tableContainer.innerHTML = testRes;
                                    //document.body.appendChild(tableContainer);
                                    //const renderTable = tableContainer.innerHTML;

                                    //res.send(testRes);
                                    if (res) {

                                        let response = res.output;
                                        //const trimRes = response.replace('&', ' and ');                                        
                                        //const resp = await dataConvertion(trimRes);                                        
                                        //const finalRes = resp.replace('\n\g', '');
                                        //console.log('json resp', finalRes);
                                        //setData(finalRes);
                                        
                                        //breadcrumbs.push(newMessage);
                                        //const randomIndex = Math.floor(Math.random() * queries.length);
                                        //console.log("breadcrumb", breadcrumbs.length);

                                        setMessages(prevMessages => [
                                            ...prevMessages,
                                            { text: response, sender: 'bot', question: newMessage, tableres: res}
                                        ]);
                                    }
                                    setLoading(false);
                                } catch (error) {
                                    console.error('Error:', error);
                                    setMessages(prevMessages => [
                                        ...prevMessages,
                                        { text: "Sorry, I can't assist you on this Query. Please ask question related to your data", sender: 'bot', question: '', tableres: '' }
                                    ]);

                                    setLoading(false);
                                }
                            }
                        };

                        useEffect(() => {
                            // Replace this with any initial welcome or greeting message from the chatbot
                            setMessages([...messages, { text: 'Welcome to the NextGen CPO Assistance! Ask me questions...', sender: 'bot', question: '', tableres: '' }]);
                        }, []);

                        return ( <
                            div style = { chatbotContainerStyle } >
                            <
                            div style = { inputContainerStyle } >
                            <
                            input type = "text"
                            ref = { inputRef }
                            style = { inputStyle }
                            placeholder = "Type your message..."
                            onKeyPress = {
                                (e) => {
                                    if (e.key === 'Enter') {
                                        handleSendMessage();
                                    }
                                }
                            }
                            />  <
                            button style = { sendButtonStyle }
                            onClick = { handleSendMessage } > {
                                loading ? ( <
                                    div className = "loading-spinner" >
                                    <
                                    BeatLoader size = { 6 }
                                    color = "#fff"
                                    loading = { true }
                                    /> < /
                                    div > ) : ( < div > Send < /div > )
                                    } <
                                    /button> < /
                                div >

                                <
                                div style = { chatboxStyle } > {
                                    messages.slice().reverse().map((message, index) => ( <
                                        div key = { index }
                                        style = { messageStyle(message.sender) } > <
                                        div className = { 'message ${message.sender}' } > < /div> <
                                        div className = "message-text" > { message.text } < /div>
                                        <DisplayTable data = { message.tableres } />
                                        <
                                        div > < /div> 

                                        <
                                        /
                                        div >
                                    ))
                                } < /
                                div >

                                <
                                div className = "chatboxStyle" > {
                                    queries.length > 0 ?
                                    <
                                    div className = "breadcrumbs" > {

                                        queries.slice(1, 5).map((breadcrumb, index) => ( <
                                            div key = { index }
                                            className = "breadcrumb"
                                            onClick = {
                                                () => handleSendMessage(breadcrumb)
                                            } > { breadcrumb } <
                                            /div>
                                        ))
                                    } <
                                    /div>  : < ></ >
                                }

                                <
                                /div > < /
                                div >
                            );
                        };

                        const chatbotContainerStyle = {

                            border: '2px solid #ccc',
                            display: 'flex',
                            flexDirection: 'column',
                            height: '500px',
                        };

                        const chatboxStyle = {
                            flex: 1,
                            padding: '10px',
                            overflowY: 'auto',
                        };

                        const messageStyle = (sender) => ({
                            background: sender === 'bot' ? '#f0f0f0' : '#E91B13',
                            color: sender === 'bot' ? '#000' : '#fff',
                            padding: '5px 10px',
                            borderRadius: '5px',
                            marginBottom: '5px',
                            width: '70%',
                            fontSize: '1.2rem',
                            marginBottom: '10px',
                            marginLeft: sender === 'bot' ? '0%' : 'auto', // Adjust this value as needed
                            marginRight: sender === 'bot' ? 'auto' : '0%',
                            alignSelf: sender === 'bot' ? 'flex-start' : 'flex-end',

                        });

                        const inputContainerStyle = {
                            display: 'flex',
                            padding: '5px',

                        };

                        const inputStyle = {
                            flex: 1,
                            padding: '8px',
                            borderRadius: '5px 0 0 5px',
                            border: '1px solid #ccc',
                        };

                        const sendButtonStyle = {
                            padding: '4px 4px',
                            borderRadius: '0 5px 5px 0',
                            border: 'none',
                            background: '#E91B13',
                            color: '#fff',
                            cursor: 'pointer',

                        };

                        export default Chatbot;