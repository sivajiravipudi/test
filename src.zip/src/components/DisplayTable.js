const DisplayTable = ({ data }) => {
    let jsondata = {};
    try {
        if (data) {
            console.log('inside if', data);
            const index = data.indexOf('{');
            const lastIndex = data.lastIndexOf('}');
            if (index != -1 && lastIndex != -1)
                data = data.substring(index, lastIndex + 1);

            console.log(typeof data);
            jsondata = JSON.parse(data);
            console.log(typeof jsondata);

            console.log(jsondata.length);
            //jsondata = data;
        }
    } catch (error) {
        console.error('Érror', error);
    }
    const headerStyle = {

        backgroundColor: '#61dafb7a',

        color: 'black',

        padding: '10px',

        border: '1px solid black'

    };



    const rowStyle = {

        backgroundColor: 'lightgrey',

        padding: '10px',

        border: '1px solid black'

    };



    const renderHeaders = (jsondata) => {

        return Object.keys(jsondata).map((key, index) => (

            <
            th key = { index }
            style = { headerStyle } > { key } < /th>

        ));

    };



    const renderValues = (jsondata) => {

        return Object.values(jsondata).map((value, index) => (

            <
            td key = { index }
            style = { rowStyle } > { formatValue(value) } < /td>

        ));

    };



    const formatValue = (value) => {

        if (Array.isArray(value)) {

            return value.join(', ');

        } else if (typeof value === 'object' && value !== null) {

            return Object.entries(value)

            .map(([key, val]) => `${key}: ${val}`)

            .join(', ');

        }

        return value;

    };


    return (

        <
        table style = {
            { borderCollapse: 'collapse', padding: '10px', width: '100%' }
        } >

        <
        thead >

        <
        tr > {
            renderHeaders(jsondata)
        } < /tr >

        <
        /thead>

        <
        tbody >

        <
        tr > {
            renderValues(jsondata)
        } < /tr >

        <
        /tbody>

        <
        /table>

    );

};

export default DisplayTable;