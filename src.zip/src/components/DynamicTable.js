import React, { useEffect, useState } from 'react';
import { json } from 'react-router-dom';

const DynamicTable = ({ jsondata }) => {
    //const [data1, setData1] = useState([]);
    let data = {};
    //console.log(jsondata)
    try {
        if (jsondata) {
            console.log('inside if', jsondata);
            data = JSON.parse(jsondata);
        }
    } catch (error) {
        console.error('Érror', error);
    }
    
    // Get keys for column headers
    const headers = jsondata.length > 0 ? Object.entries(data) : [];
    //console.log('dynamictable', headers);

    return ( <
        table lassName = 'fixed-table' >
        <
        thead >
        <
        /
        thead > <
        tbody > {
            jsondata.length > 0 ? headers.map((item, index) => ( <
                tr key = { index } > {
                    Object.values(item).map((value, i) => ( <
                        td key = { i } > { value } < /td>
                    ))
                } <
                /tr>
            )) : < div > < /div>
        } <
        /tbody> < /
        table >
    );
};

export default DynamicTable;